package logica;

import POJOS.*;
import persistencia.CocinaDAO;

import java.util.Collection;
import java.util.List;

public class GestorCocina {


    public static void comprobarConexion() {
        int resultado = CocinaDAO.conectarHibernateDAO();
        System.out.println(resultado == 0 ? "Conexión correcta" : "Error de conexión");
    }


    //EJERCICIO 1
    public static void insertarCocineroConPremios
            (Cocinero cocinero, Contactococinero contactococinero, Collection<Premio> premios) {
        int resultado = CocinaDAO.insertarCocineroConPremios(cocinero, contactococinero, premios);
        switch (resultado) {
            case 0:
                System.out.println("Cocinero insertado con éxito");
                break;
            case -1:
                System.out.println("El cocinero ya existe en la Base de Datos");
                break;
            case -2:
                System.out.println("APODO DUPLICADO: Ya hay un cocinero con este apodo");
                break;
            case -3:
                System.out.println("PREMIO DUPLICADO: El premio (nombre-año) ya existe.");
                break;
            case -9:
                System.out.println("Error inesperado.");
        }

    }

    //EJERCICIO 2
    public static void mostrarPublicacionesPorEditorial() {
        List<Object[]> lista = CocinaDAO.mostrarPublicacionesEditorial();
        System.out.printf("%-20s %-20s","Editorial","Publicaciones");
        System.out.println("\n-------------------------------------");
        //System.out.println(lista.size()); //comprobar si hay algo dentro

        for (Object[] fila : lista) {
            Long total = (Long) fila[0];       // count
            String editorial = (String) fila[1]; // editorial

            System.out.printf("%-20s %-20d%n", editorial, total);
        }
    }

    //EJERCICIO 3 POR NOMBRE
    public static void borrarRecetaPorNome(String nomeReceta){
        boolean borrado = CocinaDAO.borrarRecetaPorNome(nomeReceta);
        System.out.println(borrado ? "Receta " + nomeReceta + " borrada con éxito." : "No existe la receta");
    }

    //EJERCICIO 3 POR ID
    public static void borrarRecetaPorId(int codReceta){
        boolean borrado = CocinaDAO.borrarRecetaPorId(codReceta);
        System.out.println(borrado ? "Receta " + codReceta + " borrada con éxito" : "No existe la receta.");

    }

    //EJERCICIO 4
    public static void mostrarPropietario(String nomeRestaurante) {

        Cocinero c = CocinaDAO.mostrarPropietarioDAO(nomeRestaurante);

        if (c == null) {
            System.out.println("No existe el restaurante.");
            return;
        }

        System.out.println("El dueño del restaurante " + nomeRestaurante + " es:");
        System.out.println(
                c.getNombre().toUpperCase() + " " + c.getApellido1().toUpperCase() + " alias " + c.getApodo().toUpperCase()
        );
    }

    public static void borrarCocinero(int idCocinero) {
        boolean borrado = CocinaDAO.BorrarCocineroPorId(idCocinero);
        System.out.println(borrado ? "Cocinero " + idCocinero + "borrado con éxito." : "El cocinero no existe");
    }

    public static void insertarCocineroSimple(Cocinero cocinero, Contactococinero contacto) {

        int resultado = CocinaDAO.insertarCocinero(cocinero, contacto);

        switch (resultado) {

            case 0:
                System.out.println("Cocinero insertado correctamente.");
                break;

            case -2:
                System.out.println("Ya existe un cocinero con ese apodo.");
                break;

            default:
                System.out.println("Error al insertar el cocinero.");
        }
    }
    public static void insertarRestaurante(String apodo, Restaurante restaurante) {
        int res = CocinaDAO.engadirRestaurante(apodo,restaurante);
        switch (res) {
            case 0 -> System.out.println("Restaurante insertado.");
            case -1 -> System.out.println("El cocinero no existe.");
            case -2 -> System.out.println("Este restaurante ya es de propietario.");
        }
    }

    public static void buscarRestaurante(String apodo, String nombreRestaurante) {
        Restaurante r = CocinaDAO.buscarRestaurante(apodo, nombreRestaurante);

        if (r == null) {
            System.out.println("No existe el restaurante '"
                    + nombreRestaurante + "' del cocinero '"
                    + apodo + "'.");
            return;
        }

        System.out.println("RESTAURANTE ENCONTRADO:");
        System.out.println("Nombre: " + r.getNombrerestaurante());
        System.out.println("Tenedores: " + r.getTenedores());
        System.out.println("Localidad: " + r.getLocalidad());
    }

    public static void borrarRestaurante(String apodo, String nombreRestaurante) {
        int resultado = CocinaDAO.borrarRestaurante(apodo,nombreRestaurante);
        switch (resultado) {
            case 0 -> System.out.println("Restaurante borrado.");
            case -1 -> System.out.println("El cocinero no existe.");
            case -2 -> System.out.println("El restaurante no existe.");
        }
    }

    public static void insertarPublicacion(String apodo, Publicacion pub) {
        int res = CocinaDAO.insertarPublicacion(apodo, pub);

        switch (res) {
            case 0 -> System.out.println("Publicación asociada correctamente.");
            case -1 -> System.out.println("No existe el cocinero.");
            case -2 -> System.out.println("La publicación ya estaba asociada.");
            default -> System.out.println("Error al insertar publicación.");
        }
    }

    public static void mostrarPublicacion(int id) {
        Publicacion p = CocinaDAO.buscarPublicacionporId(id);

        if (p == null) {
            System.out.println("Publicación no encontrada.");
            return;
        }

        System.out.println("PUBLICACIÓN:");
        System.out.println("Título: " + p.getTitulo());
        System.out.println("Editorial: " + p.getEditorial());
        System.out.println("Precio: " + p.getPrecio());
    }

    public static void borrarPublicacion(int id) {
        int res = CocinaDAO.borrarPublicacionPorId(id);

        switch (res) {
            case 0 -> System.out.println("Publicación eliminada correctamente.");
            case -1 -> System.out.println("No existe la publicación.");
            default -> System.out.println("Error al borrar publicación.");
        }
    }

    public static void insertarReceta(String apodo, Receta receta) {

        int res = CocinaDAO.insertarReceta(apodo, receta);

        switch (res) {
            case 0 -> System.out.println("receta añadida correctamente");
            case -1 -> System.out.println("no existe el cocinero");
            case -2 -> System.out.println("ya existe una receta con ese nombre");
            default -> System.out.println("error al insertar receta");
        }
    }

    public static void mostrarRecetaPorId(int idReceta) {
        Receta r = CocinaDAO.buscarReceta(idReceta);

        if (r == null) {
            System.out.println("receta no encontrada");
            return;
        }

        System.out.println("receta: " + r.getNome());
        System.out.println("dificultad: " + r.getDificultade());
        System.out.println("tiempo: " + r.getTempo());
        System.out.println("autor: " + r.getCocinero().getApodo());
    }

    public static void mostrarRecetaPorNombre(String nombre) {
        Receta r = CocinaDAO.buscarRecetaPorNombre(nombre);

        if (r == null) {
            System.out.println("receta no encontrada");
            return;
        }

        System.out.println("receta: " + r.getNome());
        System.out.println("dificultad: " + r.getDificultade());
        System.out.println("tiempo: " + r.getTempo());
        System.out.println("autor: " + r.getCocinero().getApodo());
    }

    public static void mostrarRecetasDeCocinero(String apodo) {

        List<Receta> recetas = CocinaDAO.buscarRecetasDeCocinero(apodo);

        if (recetas == null || recetas.isEmpty()) {
            System.out.println("no hay recetas para ese cocinero");
            return;
        }

        System.out.println("recetas de " + apodo + ":");

        for (Receta r : recetas) {
            System.out.println("- " + r.getNome() + " (" + r.getDificultade() + ")");
        }
    }
}
