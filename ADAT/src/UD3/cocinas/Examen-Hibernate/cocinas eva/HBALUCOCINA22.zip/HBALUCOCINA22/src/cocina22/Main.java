package cocina22;

import POJOS.*;
import logica.GestorCocina;

import java.util.ArrayList;
import java.util.Collection;

public class Main {

    public static void main(String[] args) {
        //conexion
        //GestorCocina.comprobarConexion();

        //region ejercicio 1
//
//        Cocinero cocineroBien = new Cocinero("Eva","Otero","Nazara",'M',"Junior");
////        Cocinero cocineroMal = new Cocinero("Otro","Nombre","de Cocinero",'M',"Junior");
////
//         Contactococinero contactococinero = new Contactococinero("eva@gmail.com", "666555444","986555444");
//       Premio p1 = new Premio("CUCHILLO PLATINO",2020);
//       Premio p2 = new Premio("Premio DAM",2025); //premio repetido que no deberia insertarse
//        Premio p3 = new Premio("AAA",2026);
//        Premio p4 = new Premio("PREMIO BUENO",2027);
////
//         Collection<Premio> premios = new ArrayList<>();
//        premios.add(p1);
//        premios.add(p2);
//        premios.add(p3);
//        premios.add(p4);
//
//         GestorCocina.insertarCocineroConPremios(cocineroBien,contactococinero,premios);
////        GestorCocina.insertarCocineroConPremios(cocineroMal,contactococinero,premios);

        //endregion:

        //region ejercicio 2:
        //GestorCocina.mostrarPublicacionesPorEditorial();

        //endregion

        //region ejercicio 3:
//        GestorCocina.borrarRecetaPorId(21);
//        GestorCocina.borrarRecetaPorId(9999);
//        GestorCocina.borrarRecetaPorNome("Prueba");
//        GestorCocina.borrarRecetaPorNome("No existe");

        //endregion

        //region 3.5 recetas
//        Receta nueva = new Receta(
//                "lletas",
//                "media",
//                20.0,
//                "ponle toda la vainilla"
//        );
//
//        GestorCocina.insertarReceta("guapo", nueva);
//
//        GestorCocina.mostrarRecetasDeCocinero("guapo");
//        GestorCocina.mostrarRecetasDeCocinero("no existe");
//        GestorCocina.mostrarReceta(2);
//        GestorCocina.mostrarReceta(999);
//        GestorCocina.mostrarRecetaPorNombre("LLETAS");
        //endregion

        //region ejercicio 4:

//        GestorCocina.mostrarPropietario("El negro");
//        GestorCocina.mostrarPropietario("No existe");

        //endregion

//        GestorCocina.borrarCocinero(17);


        //region buscar en componente lista
//        GestorCocina.buscarRestaurante("JULIANIN","Casa Xian");
//        GestorCocina.buscarRestaurante("JULIANIN","No existe");
//        GestorCocina.buscarRestaurante("No existe","Casa Xian");

        //endregion

        //region añadir cocinero simple
//        Cocinero nuevo = new  Cocinero("Pablo","Lopez","Couso",'H',"guapo");
//        Contactococinero contacto2 = new Contactococinero("pablo@pablo.com","66688899","888999666");
//        GestorCocina.insertarCocineroSimple(nuevo,contacto2);

        //endregion

        //region insertar restaurante
//        Restaurante restaurante = new Restaurante("Manin",2,"Sanxenxo");
//        GestorCocina.insertarRestaurante("guapo",restaurante);
//        GestorCocina.insertarRestaurante("guapo",restaurante); //no se añade porque ya lo tiene

        //endregion

        //region borrar restaurante
//        GestorCocina.borrarRestaurante("guapo","Manin");
//        GestorCocina.borrarRestaurante("guapo","Noexiste");
        //endregion

        //region crear / buscar / borrar de many to many pura
//        Publicacion pub = new Publicacion("Publicacion Prueba", "Editorial", 9.50, "Libro", "ISBN-1234", 1, 2025);
//        GestorCocina.insertarPublicacion("guapo",pub);

//        GestorCocina.mostrarPublicacion(14);
//        GestorCocina.borrarPublicacion(0); //borro la 0 ya de paso que la hice sin querer

        //endregion


    }
    
}
