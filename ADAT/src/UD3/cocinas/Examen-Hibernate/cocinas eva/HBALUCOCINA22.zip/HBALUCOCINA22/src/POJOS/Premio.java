package POJOS;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Premio implements Serializable {
    private int idpremio;
    //private int codCocinero; NO HACE FALTA se gestiona la FK en cocinero
    //se quita tambien del maepado
    private String premio;
    private int anho;

    //cada premio solo tiene un cocinero
    Cocinero cocinero;

    public Premio(){}

    //el codigo del cocinero NO se pone en el constructor
    //int codCocinero
    public Premio(String premio, int anho) {
       // this.codCocinero = codCocinero;
        this.premio = premio;
        this.anho = anho;
    }

    //SOBREESCRIBIR : sólo te importa el año y el nombre para ver si se añaden al set o no

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Premio)) return false;
        Premio p = (Premio) o;
        return anho == p.anho &&
                Objects.equals(premio, p.premio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(premio, anho);
    }

//    @Override
//    public boolean equals(Object o) {
//        if (!(o instanceof Premio premio1)) return false;
//        return idpremio == premio1.idpremio && codCocinero == premio1.codCocinero && anho == premio1.anho && Objects.equals(premio, premio1.premio) && Objects.equals(cocinero, premio1.cocinero);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(idpremio, codCocinero, premio, anho, cocinero);
//    }
public void setAnho(int anho) {
    this.anho = anho;
}

    public int getAnho() {
        return anho;
    }
    public int getIdpremio() {
        return idpremio;
    }

    public void setIdpremio(int idpremio) {
        this.idpremio = idpremio;
    }

    public String getPremio() {
        return premio;
    }

    public void setPremio(String premio) {
        this.premio = premio;
    }


    public Cocinero getCocinero() {
        return cocinero;
    }

    public void setCocinero(Cocinero cocinero) {
        this.cocinero = cocinero;
    }
}
