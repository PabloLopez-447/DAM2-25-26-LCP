package persistencia;

import POJOS.*;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.query.Query;
import utilidades.HibernateUtil;

import java.util.Collection;
import java.util.List;

public class CocinaDAO {


    public static int conectarHibernateDAO() {
        Session sesion = HibernateUtil.getSessionFactory().openSession();
        if (sesion != null) {

            sesion.close();
            return 0;
        } else {
            return -1;
        }
    }

    //EJERCICIO 1

    public static int insertarCocineroConPremios
            (Cocinero cocinero, Contactococinero contacto, Collection<Premio> premios) {

        Transaction tx = null;

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {
            //region patinadas

            //tx = sesion.beginTransaction(); //despues de comprobaciones

            //esto te da igual porque la restriccion que te pide es el apodo y el id es autoincremental
            //            if(sesion.get(Cocinero.class, cocinero.getCodigo()) != null) {
//                return -1; //el cocinero ya existe
//            }

            //endregion


            //comprobacion del apodo unico
            Query<Cocinero> q = sesion.createQuery(
                    "from Cocinero where apodo = :apodo ",
                    Cocinero.class
            );
            q.setParameter("apodo", cocinero.getApodo());
            Cocinero existente = q.uniqueResult();

            if (existente != null) {
                return -2; //cocinero con apodo ya existe
            }

            tx = sesion.beginTransaction();

            //ONE TO ONE - ASOCIAR BIDIRECCIONALMENTE: si no el contacto da error por ser nulo
            cocinero.setContacto(contacto);
            contacto.setCocinero(cocinero);


            //ONE TO MANY: poner los premios - al ser un set solo añade los que no estén repes
            //revisar que en el mapeo este como all delete orphans, porque si no la cascada delete no los añade en el save
            if (premios != null) {
                //cocinero.getPremios().addAll(premios); esto sólo NO comprueba que ya esté ne la bbdd, salta restricción unique
                for (Premio p : premios) {
                    //comprobar si ya existe ese premio con ese año, el set controla que no haya repetidos en la lista que se pasa,
                    // pero no los que ya esten en la base de datos
                    Query<Premio> qPremio = sesion.createQuery(
                            "from Premio where premio = :premio and anho = :anho",
                            Premio.class
                    );

                    qPremio.setParameter("premio", p.getPremio());
                    qPremio.setParameter("anho", p.getAnho());

                    Premio existentePremio = qPremio.uniqueResult();

                    if (existentePremio == null) {// ahora si solo te metes los que no estén
                        p.setCocinero(cocinero); //RECORDAR AÑADIR LOS COCINEROS AL PREMIO
                        cocinero.getPremios().add(p);

                    } else {
                        System.out.println("Premio repetido ignorado: " + p.getPremio() + " - " + p.getAnho());
                    }
                }

            }

            //TAMBIEN HAY QUE AÑADIR LOS PREMIOS
//            if (premios != null) {
//                for (Premio p : premios) {
//                    p.setCocinero(cocinero);
//                }
//            }

            sesion.save(cocinero);
            //sesion.save(contacto); sólo guardas el cocinero si es correcto, porque la relacion tiene un cascade all
            tx.commit();
            return 0;

        } catch (ConstraintViolationException e) {
            if (tx != null) {
                tx.rollback(); // importante deshacer transacción
            }
            System.out.println("Error: premio duplicado (misma combinación premio-año)" + e.getMessage());

            return -3;
        } catch (HibernateException e) {

            if (tx != null) {
                tx.rollback();
            }

            System.out.println("Error inesperado: " + e.getMessage());
            return -9;
        }


    }


    //EJERCICIO 2 - CONSULTA
    public static List<Object[]> mostrarPublicacionesEditorial() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = """
                    
                    select count (p),
                     p.editorial
                     from Publicacion p
                     group by p.editorial
                    order by count(p) desc
                    """;

            //no hay , antes del from
            //es count(p) no count(*)
            return session.createQuery(hql, Object[].class).list();
        }
    }


    //EJERCICIO 3
    public static boolean borrarRecetaPorId(int codReceta) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            Transaction tx = session.beginTransaction();

            //buscar la receta x id
            String hql = """
                    from Receta r where r.codreceta = :codreceta 
                    """;
            //Receta receta = session.createQuery(hql,Receta.class).setParameter("codreceta", codReceta).uniqueResult();
            Receta receta = session.get(Receta.class, codReceta);

            if (receta == null) {
                //System.out.println("Receta no encontrada en la Base de datos");
                tx.rollback();
                return false;
            }

            //que printee los datos del cocinero
            //no creo que se haga aqui pero whatever

            System.out.println("RECETA: " + receta.getNome().toUpperCase());

            Cocinero c = receta.getCocinero();
            System.out.println("AUTOR: "
                    + c.getNombre()
                    + c.getApellido1() + ", "
                    + " alias " + c.getApodo());

            //si existe, la borras
            session.delete(receta);

            tx.commit();

            return true;
        }
    }

    public static boolean borrarRecetaPorNome(String nomReceta) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            Transaction tx = session.beginTransaction();

            //buscar la receta x nombre
            String hql = """
                    from Receta r where r.nome = :nome
                    """;
            Receta receta = session.createQuery(hql, Receta.class).setParameter("nome", nomReceta).uniqueResult();

            if (receta == null) {
                tx.rollback();
                return false;
            }

            //si existe, la borras
            session.delete(receta);

            tx.commit();

            return true;
        }
    }

    //EJERCICIO 4.
    public static Cocinero mostrarPropietarioDAO(String nombreRestaurante) {

        //el join es a traves de las colecciones!! no se hace en la consulta
        //c.restaurantes es la lista
        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {
            String hql = """
                    from Cocinero c
                    join c.restaurantes r
                    where r.nombrerestaurante = :nombreRestaurante
                    """;

            Query<Cocinero> q = sesion.createQuery(hql, Cocinero.class);
            q.setParameter("nombreRestaurante", nombreRestaurante);

            return q.uniqueResult();

        } catch (Exception ex) {
            throw new RuntimeException("Error al buscar el propietario ", ex);
        }
    }

    //EXTRAS:

    //BORRAR ENTIDAD
    public static boolean BorrarCocineroPorId(int idCocinero) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            Transaction tx = session.beginTransaction();

            Cocinero cocinero = session.get(Cocinero.class, idCocinero);

            if (cocinero == null) {
                //System.out.println("Receta no encontrada en la Base de datos");
                tx.rollback();
                return false;
            }

            //si existe, la borras
            session.delete(cocinero);

            tx.commit();

            return true;
        }

    }

    //AÑADIR ENTIDAD SIMPLE
    public static int insertarCocinero(Cocinero cocinero, Contactococinero contacto) {

        Transaction tx = null;

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {

            // comprobar que no exista ya un cocinero con ese apodo
            Query<Cocinero> q = sesion.createQuery(
                    "from Cocinero where apodo = :apodo",
                    Cocinero.class
            );
            q.setParameter("apodo", cocinero.getApodo());

            Cocinero existente = q.uniqueResult();

            if (existente != null) {
                return -2; // ya existe cocinero con ese apodo
            }

            tx = sesion.beginTransaction();

            //bidireccional se asocia igual, es 1t1 depende
            cocinero.setContacto(contacto);
            contacto.setCocinero(cocinero);

            // guardas solo el cocinero
            sesion.save(cocinero);

            tx.commit();

            return 0; // todo correcto
        } catch (HibernateException e) {

            if (tx != null) {
                tx.rollback();
            }

            System.out.println("Error al insertar cocinero: " + e.getMessage());
            return -9;
        }
    }

    //AÑADIR / BUSCAR / ELIMINAR COMPONENTE LISTA
    public static int engadirRestaurante(String apodo, Restaurante restaurante) {
        Transaction tx = null;

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {
            tx = sesion.beginTransaction();

            //buscar el apodo
            //Cocinero c = sesion.get(Cocinero.class, apodo); //NO PORQUE BUSCA POR ID
            Query<Cocinero> q = sesion.createQuery("from Cocinero c where c.apodo = :apodo", Cocinero.class);
            q.setParameter("apodo", apodo);
            Cocinero c = q.uniqueResult();

            if (c == null) {
                return -1; //el cocinero no existe
            }

            //buscas el restaurante en la lsta del cocinero
            //SE BUSCA cogiendo el atributo nombre del restaurante
            for (Restaurante r : c.getRestaurantes()) {
                if (r.getNombrerestaurante().equalsIgnoreCase(restaurante.getNombrerestaurante())) {
                    return -2; //el restaurante ya es de la persona
                }
            }

            //si no añades el restaurante a la lista
            c.getRestaurantes().add(restaurante);

            tx.commit();
            return 0; //todo ok

        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            throw new RuntimeException("Erro ao engadir o restaurante", e);
        }

    }

    //el restaurante por si solo no se puede buscar porque no es una entidad
    public static Restaurante buscarRestaurante(String apodo, String nombreRestaurante) {
        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {

            // primero bscar cocinero por apodo
            Query<Cocinero> q = sesion.createQuery(
                    "from Cocinero where apodo = :apodo",
                    Cocinero.class
            );

            q.setParameter("apodo", apodo);
            Cocinero c = q.uniqueResult();

            if (c == null) {
                System.out.println("Cocinero no encontrado");
                return null; // no existe el cocinero
            }

            //despues se buscar restaurante dentro de su lista
            for (Restaurante r : c.getRestaurantes()) {
                if (r.getNombrerestaurante().equalsIgnoreCase(nombreRestaurante)) {
                    return r; // encontrado
                }
            }

            System.out.println("Restaurante no encontrado");
            return null; // no tiene ese restaurante

        }
    }


    //como es una lista y no una entidad NO se hace delete, solo remove de la lista
    public static int borrarRestaurante(String apodo, String nombreRestaurante) {

        Transaction tx = null;

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {

            //buscar cocinero por apodo
            Query<Cocinero> q = sesion.createQuery(
                    "from Cocinero where apodo = :apodo",
                    Cocinero.class
            );

            q.setParameter("apodo", apodo);
            Cocinero c = q.uniqueResult();

            if (c == null) {
                return -1; // no existe cocinero
            }

            tx = sesion.beginTransaction();

            Restaurante encontrado = null;

            //buscar restaurante en su lista
            for (Restaurante r : c.getRestaurantes()) {
                if (r.getNombrerestaurante().equalsIgnoreCase(nombreRestaurante)) {
                    encontrado = r;
                    break;
                }
            }

            if (encontrado == null) {
                return -2; // no existe restaurante
            }

            //lo borras de su lista de restaurantes
            c.getRestaurantes().remove(encontrado);

            tx.commit();
            return 0;

        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error al borrar restaurante", e);
        }
    }


    //AÑADIR / BUSCAR / ELIMINAR ENTIDAD MANY TO MANY PURA

    // INSERTAR PUBLICACIÓN A UN COCINERO
    public static int insertarPublicacion(String apodoCocinero, Publicacion publicacion) {

        Transaction tx = null;

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {
            Query<Cocinero> q = sesion.createQuery(
                    "from Cocinero where apodo = :apodo",
                    Cocinero.class
            );
            q.setParameter("apodo", apodoCocinero);
            Cocinero cocinero = q.uniqueResult();

            if (cocinero == null) {
                return -1; // no existe cocinero
            }

            tx = sesion.beginTransaction();

            //buscar si la publicación ya existe en BD
            Publicacion pubExistente = sesion.get(Publicacion.class, publicacion.getCodpublicacion());

            if (pubExistente == null) {
                sesion.save(publicacion); // si no existe, la guardamos primero en la cache

                pubExistente = publicacion;
            }

            // buscar duplicado si ya la tiene en la relacion
            if (cocinero.getPublicaciones().contains(pubExistente)) {
                return -2; // ya está asociada
            }

            //asociar desde EL PROPIETARIO
            cocinero.getPublicaciones().add(pubExistente);
            //publicacion.getCocineros().add(cocinero); //el insert real lo está haciendo el otro

            tx.commit();
            return 0;

        } catch (HibernateException e) {

            if (tx != null) tx.rollback();
            return -9;
        }
    }

    public static Publicacion buscarPublicacionporId(int idPublicacion) {
        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {
            return sesion.get(Publicacion.class, idPublicacion);
        }
    }

    public static int borrarPublicacionPorId(int idPublicacion) {
        Transaction tx = null;

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {

            Publicacion p = sesion.get(Publicacion.class, idPublicacion);

            if (p == null) {
                return -1; // no existe
            }

            tx = sesion.beginTransaction();

            //!! eliminar la relacion de los cocineros antes
            for (Cocinero c : p.getCocineros()) {
                c.getPublicaciones().remove(p);
            }

            //borrar  lapublicación
            sesion.delete(p);

            tx.commit();
            return 0;

        } catch (HibernateException e) {

            if (tx != null)
                tx.rollback();

            System.out.println(e.getMessage());
            return -9;
        }
    }

    // añadir receta a un cocinero dado su apodo
    public static int insertarReceta(String apodo, Receta receta) {

        Transaction tx = null;

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {

            // buscar cocinero por apodo
            Query<Cocinero> q = sesion.createQuery(
                    "from Cocinero where apodo = :apodo",
                    Cocinero.class
            );
            q.setParameter("apodo", apodo);

            Cocinero c = q.uniqueResult();

            if (c == null) {
                return -1; // no existe cocinero
            }

            tx = sesion.beginTransaction();

            // comprobar que no tenga ya una receta con ese nombre
            for (Receta r : c.getRecetas()) {
                if (r.getNome().equalsIgnoreCase(receta.getNome())) {
                    return -2; // ya tiene una receta con ese nombre
                }
            }

            // relacion bidireccional
            // como el lado propietario es receta, hay que asignar el cocinero
            receta.setCocinero(c);

            // añadir al set del cocinero
            c.getRecetas().add(receta);

            // no hace falta hacer save(receta) porque cascade es all-delete-orphan
            tx.commit();
            return 0;

        } catch (HibernateException e) {

            if (tx != null) {
                tx.rollback();
            }
            return -9;
        }
    }

    public static Receta buscarReceta(int idReceta) {

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {

            //return sesion.get(Receta.class, idReceta);
            //no va porque no el lazy por defecro esta true y no puede cargar el cocinero

            //join fetch - pilla receta y cocinero en la misma consulta
            String hql = """
                    select r
                    from Receta r
                    join fetch r.cocinero
                    where r.codreceta = :id
                    """;

            Query<Receta> q = sesion.createQuery(hql, Receta.class);
            q.setParameter("id", idReceta);

            return q.uniqueResult();
        }


    }

    //igual que id pero con lower
    public static Receta buscarRecetaPorNombre(String nombre) {

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {

            String hql = """
                select r
                from Receta r
                join fetch r.cocinero
                where lower(r.nome) = lower(:nombre)
                """;

            Query<Receta> q = sesion.createQuery(hql, Receta.class);
            q.setParameter("nombre", nombre);

            return q.uniqueResult();
        }
    }


    // devolver todas las recetas de un cocinero por apodo
    public static List<Receta> buscarRecetasDeCocinero(String apodo) {

        try (Session sesion = HibernateUtil.getSessionFactory().openSession()) {

            String hql = """
                    select r
                    from Receta r
                    where r.cocinero.apodo = :apodo
                    """;

            Query<Receta> q = sesion.createQuery(hql, Receta.class);
            q.setParameter("apodo", apodo);

            return q.list();
        }
    }


}
