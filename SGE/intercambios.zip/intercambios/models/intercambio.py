from odoo import fields, models

class Intercambio(models.Model):
    _name = "intercambios.intercambio"
    _description = "Intercambios"

    user_a_id = fields.Many2one('res.users', string='Usuario A', required=True)
    card_a_id = fields.Many2one('intercambios.carta', string='Carta A', required=True)

    user_b_id = fields.Many2one('res.users', string='Usuario B', required=True)
    card_b_id = fields.Many2one('intercambios.carta', string='Carta B', required=True)

    state = fields.Selection([
        ('draft', 'Borrador'),
        ('done', 'Confirmado')
    ], default='draft')

    def action_confirm(self):
        for intercambio in (self):
            intercambio.card_a_id.id_propietario = intercambio.user_b_id
            intercambio.card_b_id.id_propietario = intercambio.user_a_id
            intercambio.state = 'done'




    