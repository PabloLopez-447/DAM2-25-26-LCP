from odoo import models, fields

class Carta(models.Model):
    _name= "intercambios.carta"
    _description = 'Carta'

    name = fields.Char(required = True)
    id_propietario = fields.Many2one('res.users', string='Propietario', required=True)