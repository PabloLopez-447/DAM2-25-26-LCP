{
	"name":"Intercambios",
	"summary": "Herramienta de Intercambios",
	"description": "Herramienta para la gestion de intercambio de cartas",
	"version": "17.0.1.0.0",
	"author": "Pablo López Couso",
    "category": "Tools",
    "license": "AGPL-3",
    "depends": ["base"], # type: ignore
    "data": [
        "security/ir.model.access.csv",
        "views/carta_views.xml",
        "views/intercambio.xml",
	],
    "installable": True,
}
