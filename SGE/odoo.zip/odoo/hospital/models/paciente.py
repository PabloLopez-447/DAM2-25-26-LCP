from odoo import models, fields, api

class paciente(models.Model):
    # definicion de la tabla en postgres
    _name = "hospital.paciente"
    _description =  "Tabla de pacientes "
    #_rec_name = "Rec name Paciente"

    #defincion de los campos de la tabla
    nombre = fields.Char('Nombre',required=True)
    microchip = fields.Char('Microchip',required=False)
    especie = fields.Selection(
        [
            ('perro', 'Perro'),
            ('gato', 'Gato'),
            ('roedor', 'Roedor'),
            ('ave', 'Ave'),
            ('conejo','Conejo'),
            ('reptil', 'Reptil'),
            ('otro', 'Otro')
        ],
        string='Especie',required=True
    )
    fecha_nacimiento = fields.Date(string='Fecha de Nacimiento',required=False)

    #enlace a tabla propietario
    propietario_id = fields.Many2one('hospital.propietario',string='Propietario',required=True)
