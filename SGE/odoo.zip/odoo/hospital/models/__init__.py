from . import paciente
from . import propietario
