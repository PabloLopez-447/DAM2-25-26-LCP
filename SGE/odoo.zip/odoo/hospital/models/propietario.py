from odoo import models, fields, api

class propietario(models.Model):
    # definicion de la tabla en postgres
    _name = "hospital.propietario"
    _description =  "Tabla de propietarios "

    #defincion de los campos de la tabla
    nombre = fields.Char('Nombre',required=True)
    direccion = fields.Char('Direccion',required=False)
    telefono = fields.Char('Telefono',required=True)

    #al reves que las mascotas -> ruta,campo de la otra clase, nombre
    pacientes_ids = fields.One2many('hospital.paciente','propietario_id',string='Mascotas')

