{
    "name": "Hospital",
    "summary": "Herramienta para gestion de pacientes y propietarios",  # Module subtitle phrase
    "description": "Gestion de pacientes y propietarios", 
    "version": "17.0.1.0.0",
    "author": "Eva Maria Otero Nazara",
    "category": "Tools",    
    "license": "AGPL-3",
    "depends": ["base"], 
    "data": [
        "security/ir.model.access.csv",
        "views/paciente_view.xml",
        "views/propietario_view.xml",
	],
}
