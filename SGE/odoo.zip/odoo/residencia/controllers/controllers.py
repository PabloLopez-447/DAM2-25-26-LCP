# -*- coding: utf-8 -*-
# from odoo import http


# class Residencia(http.Controller):
#     @http.route('/residencia/residencia', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/residencia/residencia/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('residencia.listing', {
#             'root': '/residencia/residencia',
#             'objects': http.request.env['residencia.residencia'].search([]),
#         })

#     @http.route('/residencia/residencia/objects/<model("residencia.residencia"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('residencia.object', {
#             'object': obj
#         })

