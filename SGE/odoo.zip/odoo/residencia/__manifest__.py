# -*- coding: utf-8 -*-
{
    'name': "residencia",
    'summary': "Descripción corta del módulo",
    'description': """
Descripción larga del módulo
    """,
    'author': "Eva Otero",
    'category': 'Tools',
    'version': '17.0.1.0.0',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

